### Test Setup
* download chromedriver
* if you've done ```npm install --dev``` already, the selenium-webdriver module should be available
* run ```public/server/integrationTests.js```
### Standalone

You can download Roboserver for Windows, OS X, or Linux [here](https://www.patreon.com/posts/12155391). Unpack and run it when the download finishes. You'll also need to remove "127.0.0.0/8" from the blacklist in your OpenComputers configuration file, otherwise your robot will be unable to connect.

Congratulations, you're halfway done! Now let's get a robot set up.

If you just want to try the program out without any fuss, I recommend using a Creative robot. Read how [here](creative-robot-install.md). If you want to use this in a survival world, you'll want to follow the steps [here](survival-robot-install.md).
var config = {};

config.webServerPort = '8080';
config.expressSessionSecret = "testSecret"

module.exports = config;